# -*-mode: python; coding: utf-8 -*-
#
# Copyright 2002-2014 Cendio AB.
# For more information, see http://www.cendio.com
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
