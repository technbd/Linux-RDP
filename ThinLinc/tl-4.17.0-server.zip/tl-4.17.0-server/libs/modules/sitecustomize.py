# -*-mode: python; coding: utf-8 -*-
#
# Copyright 2021 Pierre Ossman for Cendio AB.
# For more information, see http://www.cendio.com
if 82 - 82: Iii1i
import os
import sys
if 87 - 87: Ii % i1i1i1111I . Oo / OooOoo * I1Ii1I1 - I1I
if 81 - 81: i1 + ooOOO / oOo0O00 * i1iiIII111 * IiIIii11Ii
for OOoOoo000O00 in list ( os . environ ) :
 if OOoOoo000O00 . startswith ( "PYTHON" ) :
  del os . environ [ OOoOoo000O00 ]
  if 55 - 55: o0Oo - ii1I1iII1I1I . i1I1IiIIiIi1 % oo0O000ooO * iIIiiIIiii1
for OOoOoo000O00 in list ( os . environ ) :
 if OOoOoo000O00 . startswith ( "__TL_ORIGPYTHON" ) :
  iIi1ii1I1iI11 = OOoOoo000O00 [ len ( "__TL_ORIG" ) : ]
  os . environ [ iIi1ii1I1iI11 ] = os . environ [ OOoOoo000O00 ]
  del os . environ [ OOoOoo000O00 ]
  if 55 - 55: I11II1Ii % iIi
  if 76 - 76: i11 / i1 . Ii . i1i1i1111I + iIIiiIIiii1
  if 31 - 31: oo0O000ooO * I11II1Ii / OooOoo
  if 93 - 93: oo0O000ooO % oo0O000ooO / I1I - Oo . ii1I1iII1I1I
  if 46 - 46: i1I1IiIIiIi1 - Ii * Oo * Ii
  if 52 - 52: Oo + I1I / I11II1Ii / OooOoo - I1Ii1I1 - ooOOO
  if 60 - 60: i1I1IiIIiIi1 . I11II1Ii
i1iiiiIIIiIi = os . path . dirname ( __file__ )
if i1iiiiIIIiIi in sys . path :
 sys . path . remove ( i1iiiiIIIiIi )
 try :
  del sys . modules [ "sitecustomize" ]
  if 22 - 22: o0Oo . i1I1IiIIiIi1 + ii1I1iII1I1I + I11II1Ii
  if 85 - 85: OooOoo - oOo0O00 / Ii / I11II1Ii % i1iiIII111 . Ii
  if 7 - 7: iIIiiIIiii1 - I1Ii1I1 % iIIiiIIiii1 . I1Ii1I1 . i1i1i1111I
  import sitecustomize
 finally :
  sys . path . insert ( 0 , i1iiiiIIIiIi )
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
