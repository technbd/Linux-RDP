ThinLinc Remote Desktop Server Bundle - Version 4.17.0

This bundle contains the complete ThinLinc Remote Desktop Server.

To begin installation of ThinLinc Remote Desktop Server, double-click
the "Click to Install" icon or run the script named "install-server"
from a command prompt, both located in the top folder of this bundle.

Release notes and "Administrator's Guide" of ThinLinc Remote Desktop
Server are found in folder doc/adminguide/ in this bundle.


Copyright 2007-2024 Cendio AB.
For more information, see http://www.cendio.com

